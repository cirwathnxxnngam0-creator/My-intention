// ออกรุ่นใหม่ของเว็บ: เขียนเลขรุ่นใน js/data.js, สร้าง version.json (รายชื่อไฟล์ + บันทึกการเปลี่ยนแปลง) และไฟล์ ZIP สำหรับดาวน์โหลด
// ใช้ (ในโฟลเดอร์ site):  node release.mjs 1.2.0 "เพิ่มนักปราชญ์" "แก้หน้าตั้งค่า"
//   ไม่ใส่เลขรุ่น = สร้างไฟล์ใหม่จากรุ่นเดิม (ใช้เมื่อแก้ไฟล์แต่ยังไม่อยากให้แอปเห็นว่ามีรุ่นใหม่)
import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";
import { fileURLToPath } from "node:url";

const root = path.dirname(fileURLToPath(import.meta.url));
const [ver, ...notes] = process.argv.slice(2);
const dataPath = path.join(root, "js", "data.js");
let data = fs.readFileSync(dataPath, "utf8");
const cur = data.match(/version: '([^']+)'/)[1];
const version = ver || cur;
if (!/^\d+\.\d+\.\d+$/.test(version)) { console.error("เลขรุ่นต้องเป็นแบบ 1.2.3"); process.exit(1); }
const today = new Date().toISOString().slice(0, 10);
data = data.replace(/version: '[^']+'/, `version: '${version}'`).replace(/released: '[^']+'/, `released: '${ver ? today : data.match(/released: '([^']+)'/)[1]}'`);
fs.writeFileSync(dataPath, data);

// รายชื่อไฟล์ที่แอปเก็บไว้ใช้ออฟไลน์ (ไม่รวม ZIP, version.json และสคริปต์นี้)
const SKIP = new Set(["version.json", "release.mjs", "README.txt"]);
function walk(dir, rel = "") {
  let out = [];
  for (const n of fs.readdirSync(dir).sort()) {
    const p = path.join(dir, n), r = rel ? rel + "/" + n : n;
    if (n.startsWith(".") || r === "download" || n.endsWith(".partial.json")) continue;
    if (fs.statSync(p).isDirectory()) out = out.concat(walk(p, r));
    else if (!SKIP.has(r)) out.push(r);
  }
  return out;
}
const files = walk(root);
const prev = fs.existsSync(path.join(root, "version.json")) ? JSON.parse(fs.readFileSync(path.join(root, "version.json"), "utf8")) : {};
const info = { version, date: ver ? today : prev.date || today, notes: ver ? notes : prev.notes || [], files: ["./", ...files] };
fs.writeFileSync(path.join(root, "version.json"), JSON.stringify(info, null, 1) + "\n");

// ZIP (เขียนเอง ไม่ต้องติดตั้งแพ็กเกจ)
const crcTable = new Uint32Array(256).map((_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; return c >>> 0; });
const crc32 = (b) => { let c = 0xffffffff; for (const x of b) c = crcTable[(c ^ x) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
const now = new Date(), dosTime = (now.getHours() << 11) | (now.getMinutes() << 5) | (now.getSeconds() >> 1), dosDate = ((now.getFullYear() - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate();
const parts = [], central = [];
let offset = 0;
for (const r of [...files, "version.json", "README.txt", "release.mjs"].filter((f) => fs.existsSync(path.join(root, f)))) {
  const raw = fs.readFileSync(path.join(root, r)), comp = zlib.deflateRawSync(raw), name = Buffer.from("jetchamnong-site/" + r, "utf8"), crc = crc32(raw);
  const local = Buffer.alloc(30); local.writeUInt32LE(0x04034b50, 0); local.writeUInt16LE(20, 4); local.writeUInt16LE(0x0800, 6); local.writeUInt16LE(8, 8); local.writeUInt16LE(dosTime, 10); local.writeUInt16LE(dosDate, 12);
  local.writeUInt32LE(crc, 14); local.writeUInt32LE(comp.length, 18); local.writeUInt32LE(raw.length, 22); local.writeUInt16LE(name.length, 26);
  const cen = Buffer.alloc(46); cen.writeUInt32LE(0x02014b50, 0); cen.writeUInt16LE(20, 4); cen.writeUInt16LE(20, 6); cen.writeUInt16LE(0x0800, 8); cen.writeUInt16LE(8, 10); cen.writeUInt16LE(dosTime, 12); cen.writeUInt16LE(dosDate, 14);
  cen.writeUInt32LE(crc, 16); cen.writeUInt32LE(comp.length, 20); cen.writeUInt32LE(raw.length, 24); cen.writeUInt16LE(name.length, 28); cen.writeUInt32LE(offset, 42);
  parts.push(local, name, comp); central.push(cen, name);
  offset += 30 + name.length + comp.length;
}
const cenBuf = Buffer.concat(central), end = Buffer.alloc(22);
end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(central.length / 2, 8); end.writeUInt16LE(central.length / 2, 10); end.writeUInt32LE(cenBuf.length, 12); end.writeUInt32LE(offset, 16);
fs.mkdirSync(path.join(root, "download"), { recursive: true });
fs.writeFileSync(path.join(root, "download", "jetchamnong-site.zip"), Buffer.concat([...parts, cenBuf, end]));
console.log(`รุ่น ${version} · ${files.length} ไฟล์ · ZIP ${(offset / 1024).toFixed(0)} KB`);
